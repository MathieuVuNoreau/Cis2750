----------------------------README.TXT - A4--------------------------------------
Name: Mathieu-Tien Vu-Noreau
Student ID : 0884903
Student Email : mvunorea@mail.uoguelph.ca
Class : CIS*2750 - Software System Dvlmt & Intgrn
Instructor: David Calvert
Date: October 10th 2016
Assignment: Assignment 4 - Database Intergation

Welcome to what will hopefully be my last assignemnt for cis 2750


To make the program run successfully you will neeed to do the following when running the program
run chmod a+rw on a4.php
run chmod a+rw on both convert.php and store.php 
run chmod a+rw on main.js
run chmod a+rwx on a4.py
run chmod a+rwx on jquery-js.js

if that does not fix the issue just chmod evberything but those should about cover it.
